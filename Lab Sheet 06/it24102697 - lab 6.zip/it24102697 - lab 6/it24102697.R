setwd("C:\\Users\\it24102697\\Desktop\\it24102697 - lab 6")
getwd()
#Question 01
#Part1 
#Binomial Distribution
#Here, random variable X has binomial distribution with n=50 and p=0.85


dbinom(47,50,0.85)

#Question 02
#Part1
#Number of customer calls received in an hour

#Part2
#Poisson distribution
#Here, random variable X has poisson distribution with lambda=12

#Part3
dpois(12,15)